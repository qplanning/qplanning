"""Figure: Q-Planning self-improvement on LIBERO-10.

Three panels:
  (a) Q-function fine-tuning loss across all gradient steps.
  (b) Policy success rate after each self-improvement iteration.
  (c) Mean successful episode length after each self-improvement iteration.

Iteration 0 is the starting point (no self-improvement has yet taken place;
this matches the offline Q-Planning row of Table 3). Iterations 1..6 are after
each subsequent round of (collect 100 rollouts) -> (200 Q-only gradient steps).
"""
from common import DATA, IMG
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl

mpl.rcParams.update({
    "font.family": "serif",
    "font.size": 13,            # bumped from default 10 to compensate for LaTeX downscaling
    "axes.labelsize": 13,
    "axes.titlesize": 13,
    "xtick.labelsize": 12,
    "ytick.labelsize": 12,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.grid": True,
    "grid.linewidth": 0.5,
    "grid.alpha": 0.5,
    "legend.frameon": False,
    "savefig.bbox": "tight",
    "pdf.fonttype": 42,
})

ITER_STEPS = 200  # one self-improvement iteration = 200 Q-only gradient steps

loss = pd.read_csv(DATA / "qf_libero10_si_loss.csv")
loss.columns = ["step", "loss", "loss_min", "loss_max"]

sr = pd.read_csv(DATA / "qf_libero10_si_success_rate.csv")
sr.columns = ["step", "success", "success_min", "success_max", "ep_len"]
# Iteration 0 = pre-SI baseline (matches offline Q-Planning in Table 3)
sr["iter"] = (sr["step"] / ITER_STEPS).astype(int) - 1

# FastWAM (no Q guidance) reference, from baseline_libero_10.csv
_base = pd.read_csv(DATA / "baseline_libero_10.csv").dropna(subset=["task_id"])
_fastwam_sr = float(_base["success"].mean()) * 100
_fastwam_el = float(_base[_base["success"] == True]["episode_length"].mean())

fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(10.4, 2.6))

# (a) Q-loss
ax1.plot(loss["step"], loss["loss"], color="#1f4e79", linewidth=1.8)
ax1.set_xlabel("Q-function gradient step")
ax1.set_ylabel("Q fine-tuning loss")
ax1.set_title("(a) Q-function fine-tuning loss")

# (b) Success rate per iteration
ax2.plot(sr["iter"], sr["success"], color="#c0504d", marker="o", linewidth=1.8, markersize=6)
ax2.set_xlabel("Self-improvement iteration")
ax2.set_ylabel("Success rate (%)")
ax2.set_ylim(88, 100.5)
ax2.set_xticks(sr["iter"])
ax2.set_title("(b) Success rate")
ax2.axhline(_fastwam_sr, linestyle="--", color="gray", linewidth=1.1, alpha=0.7)
ax2.text(sr["iter"].iloc[0], _fastwam_sr - 0.4,
         f"FastWAM backbone ({_fastwam_sr:.0f}%)",
         color="gray", ha="left", va="top")

# (c) Mean successful episode length per iteration
ax3.plot(sr["iter"], sr["ep_len"], color="#548235", marker="s", linewidth=1.8, markersize=6)
ax3.set_xlabel("Self-improvement iteration")
ax3.set_ylabel("Mean ep. length (steps)")
ax3.set_xticks(sr["iter"])
ax3.set_title("(c) Episode length")
ax3.axhline(_fastwam_el, linestyle="--", color="gray", linewidth=1.1, alpha=0.7)
ax3.text(sr["iter"].iloc[-1], _fastwam_el - 1.5,
         f"FastWAM backbone ({_fastwam_el:.0f})",
         color="gray", ha="right", va="top")

fig.tight_layout()
out = IMG / "self_improvement.pdf"
fig.savefig(out, bbox_inches="tight", pad_inches=0)
print(f"Wrote {out}")
print(
    f"% iters={len(sr)}  sr: {sr['success'].iloc[0]} -> {sr['success'].iloc[-1]}  "
    f"ep_len: {sr['ep_len'].iloc[0]} -> {sr['ep_len'].iloc[-1]}  "
    f"FastWAM ref: sr={_fastwam_sr:.1f} ep_len={_fastwam_el:.0f}"
)
