"""Figure: Q-value over time for a successful and an unsuccessful LIBERO-10 episode.

Two side-by-side panels. For each episode, plot the Q-value of the MPPI-aggregated
(executed) chunk as a solid line and the Q-values of all 64 MPPI candidates per
planning step as a faint scatter. The x-axis is environment timestep
(planning_step_idx * STRIDE).
"""
from common import DATA, IMG
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

mpl.rcParams.update({
    "font.family": "serif",
    "font.size": 13,
    "axes.labelsize": 13,
    "axes.titlesize": 13,
    "xtick.labelsize": 12,
    "ytick.labelsize": 12,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.grid": True,
    "grid.linewidth": 0.5,
    "grid.alpha": 0.5,
    "legend.frameon": False,
    "savefig.bbox": "tight",
    "pdf.fonttype": 42,
})

STRIDE = 16  # action-chunk length K; one planning step every 16 env steps

EPISODES = [
    {
        "file": "eval_episode_0_planning_data.npz",
        "title": '(a) Success: "put the alphabet soup in the basket"',
        "line_color": "#2c7a3d",        # green = success
        "scatter_color": "#2c7a3d",
    },
    {
        "file": "eval_episode_2_planning_data.npz",
        "title": '(b) Failure: "turn on stove and put the moka pot on it"',
        "line_color": "#b3261e",        # red = failure
        "scatter_color": "#b3261e",
    },
]


def load_episode(name: str):
    d = np.load(DATA / name, allow_pickle=True)
    q_sel = d["q_selected"].astype(float)              # (T_plan,)
    q_cand = np.stack([np.asarray(c, dtype=float) for c in d["q_candidates"]])  # (T_plan, N)
    return q_sel, q_cand


fig, axes = plt.subplots(1, 2, figsize=(10.4, 2.8))

for ax, ep in zip(axes, EPISODES):
    q_sel, q_cand = load_episode(ep["file"])
    t_plan = np.arange(q_sel.shape[0])                 # planning step indices
    t_env  = t_plan * STRIDE                           # environment timesteps

    # Faint scatter: every MPPI candidate (N=64 per plan step)
    N = q_cand.shape[1]
    x_scatter = np.repeat(t_env, N)
    y_scatter = q_cand.reshape(-1)
    ax.scatter(x_scatter, y_scatter,
               s=6, alpha=0.18, color=ep["scatter_color"],
               edgecolors="none", zorder=1)

    # Solid line: Q of the executed (MPPI-aggregated) chunk
    ax.plot(t_env, q_sel, color=ep["line_color"], linewidth=2.0, zorder=3)

    ax.set_title(ep["title"])
    ax.set_xlabel("Episode timestep")
    ax.set_ylim(0, 1.0)

# Shared y-label only on the left panel
axes[0].set_ylabel("$Q_\\phi$ value")
axes[1].set_ylabel("")  # avoid duplication

fig.tight_layout()
out = IMG / "q_over_time.pdf"
fig.savefig(out, bbox_inches="tight", pad_inches=0)
print(f"Wrote {out}")
for ep in EPISODES:
    q_sel, q_cand = load_episode(ep["file"])
    print(f"% {ep['file']}: T_plan={len(q_sel)}, env_steps={len(q_sel)*STRIDE}, "
          f"q_sel range=[{q_sel.min():.3f}, {q_sel.max():.3f}]")
