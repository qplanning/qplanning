"""Illustrative sketch: MPPI samples fanning out from a single starting state.

Synthetic illustration (no real data). The starting state sits at the bottom-left
of the canvas and trajectory samples fan out across a 180-degree arc spanning
top-left, top, top-right, and bottom-right directions. Each trajectory has a
temporally-smoothed Brownian perturbation overlaid on its directed base
velocity, giving the visual fan-out shape that MPPI sampling produces.
"""
from common import IMG
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

mpl.rcParams.update({
    "font.family": "serif",
    "font.size": 13,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "savefig.bbox": "tight",
    "pdf.fonttype": 42,
})

rng = np.random.default_rng(42)
N = 24                    # number of sampled trajectories
T = 14                    # timesteps per trajectory
STEP_NOMINAL = 0.20       # nominal per-step base displacement
NOISE = 0.04              # per-step noise std (kept small so paths stay in-plot)
KERNEL_SD = 1.5
ORIGIN = np.array([-2.0, -2.0])
CANVAS = 3.0              # plot half-width
EDGE_MARGIN = 0.45        # safety margin from canvas edge to absorb noise

# Directions fan out from bottom-left toward top-left, top, top-right, bottom-right
ANGLE_LO = np.deg2rad(-45.0)
ANGLE_HI = np.deg2rad(135.0)
angles = rng.uniform(ANGLE_LO, ANGLE_HI, size=N)

# Temporal smoothing kernel for the per-step perturbations
k = np.exp(-0.5 * (np.arange(-3, 4) / KERNEL_SD) ** 2)
k = k / k.sum()


def safe_step(angle: float) -> float:
    """Largest per-step displacement so the unperturbed endpoint stays inside the
    canvas (with EDGE_MARGIN of slack for noise excursions)."""
    cos_a, sin_a = np.cos(angle), np.sin(angle)
    candidates = []
    if cos_a > 1e-6:
        candidates.append((CANVAS - EDGE_MARGIN - ORIGIN[0]) / cos_a)
    elif cos_a < -1e-6:
        candidates.append((-CANVAS + EDGE_MARGIN - ORIGIN[0]) / cos_a)
    if sin_a > 1e-6:
        candidates.append((CANVAS - EDGE_MARGIN - ORIGIN[1]) / sin_a)
    elif sin_a < -1e-6:
        candidates.append((-CANVAS + EDGE_MARGIN - ORIGIN[1]) / sin_a)
    return min(candidates) / T


fig, ax = plt.subplots(figsize=(4.0, 4.0))

# Starting state
ax.plot(*ORIGIN, "o", color="black", markersize=14, zorder=5)

for angle in angles:
    step = min(STEP_NOMINAL, safe_step(angle))
    base = np.array([np.cos(angle), np.sin(angle)]) * step
    noise = rng.standard_normal((T, 2)) * NOISE
    smoothed = np.stack([np.convolve(noise[:, d], k, mode="same") for d in range(2)], axis=1)
    increments = base[None, :] + smoothed
    pos = np.vstack([ORIGIN, ORIGIN + np.cumsum(increments, axis=0)])
    # Hard clip in case noise still pushes a sample over the edge
    pos = np.clip(pos, -CANVAS, CANVAS)
    ax.plot(pos[:, 0], pos[:, 1], color="#2c5aa0", alpha=0.4, linewidth=2.0, zorder=2)
    ax.plot(pos[-1, 0], pos[-1, 1], "o", color="#2c5aa0", alpha=0.65, markersize=6, zorder=3)

ax.set_aspect("equal")
ax.set_xlim(-CANVAS, CANVAS)
ax.set_ylim(-CANVAS, CANVAS)
ax.set_xticks([])
ax.set_yticks([])
for side in ("left", "bottom"):
    ax.spines[side].set_visible(False)

fig.tight_layout()
out = IMG / "mppi_random_samples.pdf"
fig.savefig(out, bbox_inches="tight", pad_inches=0)
print(f"Wrote {out}")
