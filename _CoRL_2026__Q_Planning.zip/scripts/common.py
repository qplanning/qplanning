"""Shared aggregation helpers for the CoRL 2026 Q-Planning paper scripts."""
from __future__ import annotations
from pathlib import Path
import pandas as pd

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "corl_2026_template_submission" / "data"
IMG = REPO / "corl_2026_template_submission" / "img"
IMG.mkdir(parents=True, exist_ok=True)


def load(name: str) -> pd.DataFrame:
    """Load a CSV and drop trailing blank rows."""
    df = pd.read_csv(DATA / name)
    return df.dropna(subset=["task_id"]).reset_index(drop=True)


def per_task(df: pd.DataFrame) -> pd.DataFrame:
    """Per-task success rate and mean episode length on successful episodes."""
    grp = df.groupby("task_name")
    sr = grp["success"].mean()
    el = df[df["success"] == True].groupby("task_name")["episode_length"].mean()
    out = pd.DataFrame({"success": sr, "ep_len": el}).reset_index()
    return out.sort_values("task_name").reset_index(drop=True)


def restrict_shared(*dfs: pd.DataFrame) -> list[pd.DataFrame]:
    """Restrict each per-task frame to the intersection of task names."""
    shared = set(dfs[0]["task_name"])
    for d in dfs[1:]:
        shared &= set(d["task_name"])
    return [d[d["task_name"].isin(shared)].sort_values("task_name").reset_index(drop=True) for d in dfs]


def agg(df: pd.DataFrame) -> tuple[float, float]:
    """Mean success rate and mean ep-length across tasks (in success cases)."""
    return float(df["success"].mean()), float(df["ep_len"].mean())


def fmt_sr(x: float) -> str:
    return f"{100*x:.1f}"


def fmt_el(x: float) -> str:
    return f"{x:.0f}"
