"""Figure: BC vs MPPI vs temporal-smoothed MPPI candidate diversity.

Uses real action-chunk samples from sample_viz_data.npz, showing the
candidates at the *first* MPPI iteration (before any Q-weighted update):
  - bc_mean_raw                        (32, 7)  : BC mean trajectory (overlaid solid black)
  - bc_diff_candidates_raw             (64, 32, 7) : 64 BC samples
  - mppi_iter0_candidates_raw          (64, 32, 7) : 64 MPPI iter-0 samples
  - mppi_smooth2_iter0_candidates_raw  (64, 32, 7) : 64 smoothed MPPI iter-0 samples

Plots one action dimension (chosen for highest variance separation between
methods) across the planning horizon H, with 64 faded sample trajectories
and the BC mean trajectory in solid black.
"""
from common import DATA, IMG
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

mpl.rcParams.update({
    "font.family": "serif",
    "font.size": 9,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.grid": True,
    "grid.linewidth": 0.4,
    "grid.alpha": 0.4,
    "savefig.bbox": "tight",
    "pdf.fonttype": 42,
})

DIM = 2  # normalized z-translation in the LIBERO action space; cleanest contrast
data = np.load(DATA / "sample_viz_data.npz")

bc_mean = data["bc_mean_raw"][:, DIM]
panels = [
    ("BC sampling",                data["bc_diff_candidates_raw"][:, :, DIM],            "#5b9bd5"),
    ("MPPI",                       data["mppi_iter0_candidates_raw"][:, :, DIM],         "#ed7d31"),
    ("MPPI + temporal smoothing",  data["mppi_smooth2_iter0_candidates_raw"][:, :, DIM], "#70ad47"),
]

H = bc_mean.shape[0]
t = np.arange(H)

fig, axes = plt.subplots(3, 1, figsize=(3.5, 4.6), sharex=True)
y_lo = min(panel[1].min() for panel in panels + [(None, bc_mean[None, :], None)])
y_hi = max(panel[1].max() for panel in panels + [(None, bc_mean[None, :], None)])
pad = 0.08 * (y_hi - y_lo)
y_lo -= pad
y_hi += pad

for ax, (label, samples, color) in zip(axes, panels):
    for row in samples:
        ax.plot(t, row, color=color, alpha=0.25, linewidth=0.8)
    ax.plot(t, bc_mean, color="black", linewidth=1.4, label="BC mean")
    ax.set_ylim(y_lo, y_hi)
    ax.set_title(label, fontsize=9, loc="left")
    ax.tick_params(labelsize=7.5)

axes[-1].set_xlabel("$H$")

fig.tight_layout()
out = IMG / "traj_diversity.pdf"
fig.savefig(out, bbox_inches="tight", pad_inches=0)
print(f"Wrote {out}")
